package com.health.tracker.healthactivitytracker;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.health.tracker.healthactivitytracker.dto.ActivityPayload;
import com.health.tracker.healthactivitytracker.redis.stream.producer.AbstractStreamProducer;
import com.health.tracker.healthactivitytracker.redis.stream.producer.IStreamProducer;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@SpringBootTest
public class HealthActivityTrackerApplicationTests {

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private AbstractStreamProducer activityStreamProducer;

    @Test
    void loadPayloadsFromFileAndSendToRedis() throws Exception {
        PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
        Resource[] resources = resolver.getResources("classpath:testdata/INPUT_DATA*.json");

        int round = 3;
        int threadPoolSize = 10;
        ExecutorService executorService = Executors.newFixedThreadPool(threadPoolSize);
        List<Callable<Void>> tasks = new ArrayList<>();

        long start = System.currentTimeMillis(); // 시작 시간 측정

        for (int i = 0; i < round; i++) {
            for (Resource resource : resources) { // 4개 (INPUT_DATA1,2,3,4)
                tasks.add(() -> {
                    ExecutorService sendExecutorService = Executors.newFixedThreadPool(threadPoolSize);

                    try (InputStream is = resource.getInputStream()) {
                        String rawJson = new String(is.readAllBytes(), StandardCharsets.UTF_8);
                        ActivityPayload payload = objectMapper.readValue(rawJson, ActivityPayload.class);

                        String uuid = UUID.randomUUID().toString();
                        payload.setRecordkey(uuid);

                        if (payload.getData() != null && payload.getData().getSource() != null) {
                            String originalName = payload.getData().getSource().getName();
                            payload.getData().getSource().setName(originalName);
                        }

                        sendExecutorService.submit(() -> activityStreamProducer.sendAsync(payload));
                        System.out.println("Sent from " + resource.getFilename() + " with recordKey: " + uuid);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    return null;
                });
            }
        }

        executorService.invokeAll(tasks);
        executorService.shutdown();

        long end = System.currentTimeMillis();
        long elapsedMillis = end - start;

        System.out.printf("총 소요 시간: %,d ms (%.2f초)%n", elapsedMillis, elapsedMillis / 1000.0);
    }
}
