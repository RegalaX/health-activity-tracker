package com.health.tracker.healthactivitytracker.service;

import com.health.tracker.healthactivitytracker.dto.ActivityPayload;
import com.health.tracker.healthactivitytracker.dto.Source;
import com.health.tracker.healthactivitytracker.entity.ActivityEntry;
import com.health.tracker.healthactivitytracker.entity.ActivityRecord;
import com.health.tracker.healthactivitytracker.entity.ActivityRecordSource;
import com.health.tracker.healthactivitytracker.entity.ActivityType;
import com.health.tracker.healthactivitytracker.repository.ActivityEntryJdbcRepository;
import com.health.tracker.healthactivitytracker.repository.ActivityEntryRepository;
import com.health.tracker.healthactivitytracker.repository.ActivityRecordRepository;
import com.sun.jdi.request.DuplicateRequestException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class ActivityRecordService {

    private final ActivityRecordRepository recordRepo;
    private final ActivityEntryJdbcRepository entryJdbcRepo;
    private final ActivityEntryRepository entryRepo;
    private final ActivitySourceCacheManager activitySourceCacheManager;

    @Transactional
    public void saveActivityFromPayload(ActivityPayload payload) {
        // 1. 먼저 Source를 분리 관리
        Source sourceDto = payload.getData().getSource();

        ActivityRecordSource source = activitySourceCacheManager.getOrSaveSource( // 캐시 매니저 혹은 repository
                sourceDto.getName(),
                sourceDto.getMode(),
                sourceDto.getType(),
                sourceDto.getProduct().getName(),
                sourceDto.getProduct().getVender()
        );

        recordRepo.findByRecordKey(payload.getRecordkey())
                .ifPresent(r -> {
                    throw new DuplicateRequestException("이미 처리된 recordKey: " + payload.getRecordkey());
                });


        // 2. recordKey 중복 확인
        ActivityRecord record = recordRepo.save(ActivityRecord.builder()
                .recordKey(payload.getRecordkey())
                .source(source) // source_id 참조
                .activityType(ActivityType.fromString(payload.getType()))
                .lastUpdatedAt(parseDateTime(payload.getLastUpdate()))
                .memo(payload.getData().getMemo())
                .build());

        // 3. entry 반복 저장
        List<ActivityEntry> entries = payload.getData().getEntries().stream()
                .map(entry -> ActivityEntry.builder()
                        .recordId(record.getId())
                        .startTime(parseDateTime(entry.getPeriod().getFrom()))
                        .endTime(parseDateTime(entry.getPeriod().getTo()))
                        .steps(entry.getSteps() != null ? entry.getSteps() : BigDecimal.ZERO)
                        .distanceKm(entry.getDistance() != null ? entry.getDistance().getValue() : BigDecimal.ZERO)
                        .caloriesKcal(entry.getCalories() != null ? entry.getCalories().getValue() : BigDecimal.ZERO)
                        .createdAt(LocalDateTime.now())
                        .build())
                .toList();


        List<ActivityEntry> deduplicated = mergeOrDeduplicate(entries);

        log.info("Inserting {} activity entries (deduplicated from {}) for recordKey={}",
                deduplicated.size(), entries.size(), payload.getRecordkey());

        entryJdbcRepo.batchInsert(deduplicated);
    }

    private LocalDateTime parseDateTime(String raw) {
        return LocalDateTime.parse(raw.substring(0, 19).replace(" ", "T"));
    }

    /**
     * from (start_time) 이 같은 데이터를 병합. 논리상 시작 시간(초)이 같을 수 없음.
     * */
    private List<ActivityEntry> mergeOrDeduplicate(List<ActivityEntry> entries) {
        return new ArrayList<>(
                entries.stream()
                        .collect(Collectors.toMap(
                                ActivityEntry::getStartTime,  // 중복 기준
                                e -> e,                       // 첫 값
                                (existing, duplicate) -> {    // 중복 처리 정책: 병합
                                    log.info("duplicate start time {} -> {}", existing.getStartTime(), duplicate.getStartTime());

                                    return ActivityEntry.builder()
                                            .recordId(existing.getRecordId())
                                            .startTime(existing.getStartTime())
                                            .endTime(duplicate.getEndTime().isAfter(existing.getEndTime()) ? duplicate.getEndTime() : existing.getEndTime())
                                            .steps(existing.getSteps().add(duplicate.getSteps()))
                                            .distanceKm(existing.getDistanceKm().add(duplicate.getDistanceKm()))
                                            .caloriesKcal(existing.getCaloriesKcal().add(duplicate.getCaloriesKcal()))
                                            .createdAt(existing.getCreatedAt())
                                            .build();
                                }))
                        .values()
        );
    }


}
