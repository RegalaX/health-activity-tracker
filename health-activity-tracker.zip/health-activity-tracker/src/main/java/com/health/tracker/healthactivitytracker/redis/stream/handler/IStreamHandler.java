package com.health.tracker.healthactivitytracker.redis.stream.handler;

import org.springframework.data.redis.connection.stream.MapRecord;

public interface IStreamHandler {
    void handle(MapRecord<String, Object, Object> record, String consumerName);
}