package com.health.tracker.healthactivitytracker.service;

import com.health.tracker.healthactivitytracker.entity.ActivityEntry;
import com.health.tracker.healthactivitytracker.entity.ActivityHourlySummary;
import com.health.tracker.healthactivitytracker.repository.ActivityEntryRepository;
import com.health.tracker.healthactivitytracker.repository.ActivityHourlySummaryRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class HourlySummaryAggregatorService {

    private final ActivityEntryRepository entryRepository;
    private final ActivityHourlySummaryRepository summaryRepository;

    /**
     * 10분 간격으로 실행되는 스케줄링 메서드
     *
     * 목적:
     * - 최근 1시간 동안 기록된 ActivityEntry 데이터를 가져와,
     *   recordId (사용자 식별자) + hourly 단위로 집계 데이터를 생성
     *
     * - 현재는 실시간 통계 API에서 ActivityEntry 테이블을 직접 집계하고 있으나,
     *    - 데이터 양이 많아질수록 쿼리 성능 저하 발생 가능성 있음
     *    - 중복 계산이 빈번해짐 (같은 시간 범위 반복 계산)
     *
     * 개선 방향:
     * - 미리 계산된 hourly 데이터를 활용해 daily/monthly 통계를 빠르게 생성 가능
     *   → 예: `GROUP BY DATE(hourly)` 또는 `GROUP BY DATE_FORMAT(hourly, '%Y-%m')`
     *   → 데이터 중복 계산 없이, summary 테이블 기반 집계 수행
     *
     * 안정성을 위해 동일 hourly + recordKey에 대해서 중복 저장 시도 방지 고려 필요
     */
    @Scheduled(fixedDelay = 600000) // 10분 간격
    public void scheduledHourlyAggregation() {
        log.info("[batch] Start hourly aggregation schedule");

        // 현재 시각에서 분과 초를 제거해서 가장 가까운 '정시'를 구함
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime thisHour = now.withMinute(0).withSecond(0).withNano(0);
        LocalDateTime oneHourAgo = thisHour.minusHours(1);

        log.info("[batch] Aggregation target time range: {} ~ {}", oneHourAgo, thisHour);

        // 1시간 범위의 ActivityEntry 조회
        List<ActivityEntry> entries = entryRepository.findByStartTimeBetween(oneHourAgo, thisHour);

        // recordKey 기준으로 그룹핑
        Map<Long, List<ActivityEntry>> groupedByRecordKey = entries.stream()
                .collect(Collectors.groupingBy(ActivityEntry::getRecordId));

        groupedByRecordKey.forEach((recordId, entryList) -> {
            try {
                // 정시 기준으로 aggregate (예: 07:00 → 06:00 ~ 07:00 데이터)
                aggregateHourly(recordId, oneHourAgo);
            } catch (Exception e) {
                log.error("[batch] Aggregation failed: recordId={} hourly={}", recordId, oneHourAgo, e);
            }
        });
    }


    private void aggregateHourly(Long recordId, LocalDateTime hourly) {
        LocalDateTime start = hourly;
        LocalDateTime end = hourly.plusHours(1);

        List<ActivityEntry> entries = entryRepository.findByRecordIdAndStartTimeBetween(recordId, start, end);

        BigDecimal totalSteps = entries.stream()
                .map(ActivityEntry::getSteps)
                .filter(Objects::nonNull)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal totalCalories = entries.stream()
                .map(ActivityEntry::getCaloriesKcal)
                .filter(Objects::nonNull)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal totalDistance = entries.stream()
                .map(ActivityEntry::getDistanceKm)
                .filter(Objects::nonNull)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        ActivityHourlySummary summary = ActivityHourlySummary.builder()
                .recordKey(recordId.toString()) // record_id → record_key로 변환
                .hourly(hourly)
                .steps(totalSteps.doubleValue())
                .calories(totalCalories.doubleValue())
                .distance(totalDistance.doubleValue())
                .build();

        summaryRepository.save(summary);
    }

}
