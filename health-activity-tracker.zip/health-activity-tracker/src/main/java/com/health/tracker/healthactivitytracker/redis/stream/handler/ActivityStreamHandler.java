package com.health.tracker.healthactivitytracker.redis.stream.handler;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.health.tracker.healthactivitytracker.constant.RedisStreamKey;
import com.health.tracker.healthactivitytracker.dto.ActivityPayload;
import com.health.tracker.healthactivitytracker.service.ActivityRecordService;
import org.springframework.data.redis.connection.stream.MapRecord;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

/**
 * 이 클래스는 {@link AbstractStreamHandler}를 확장하여 공통 로직을 재사용한다.
 * Redis Stream에서 활동 데이터를 소비하여 비즈니스 로직으로 전달하는 핸들러.
 * Redis Stream의 key와 Consumer Group을 기반으로 메시지를 읽고,
 * JSON으로 전달된 payload를 역직렬화하여 ActivityRecordService로 전달한다.
 */
@Component
public class ActivityStreamHandler extends AbstractStreamHandler<ActivityPayload> {

    // 활동 데이터를 저장하는 서비스
    private final ActivityRecordService recordService;

    // JSON 역직렬화를 위한 Jackson ObjectMapper
    private final ObjectMapper objectMapper;

    /**
     * 생성자: RedisTemplate, 서비스, ObjectMapper를 주입받아 Stream 설정을 초기화한다.
     *
     * @param redisTemplate Redis 연결을 위한 템플릿
     * @param recordService 활동 저장 로직을 처리하는 서비스
     * @param objectMapper  JSON → 객체 역직렬화에 사용
     */
    public ActivityStreamHandler(RedisTemplate<String, String> redisTemplate, ActivityRecordService recordService, ObjectMapper objectMapper) {
        // Redis Stream Key와 Consumer Group 이름을 상위 클래스에 전달
        super(redisTemplate, RedisStreamKey.ACTIVITY_STREAM_KEY, RedisStreamKey.ACTIVITY_CONSUMER_GROUP);
        this.recordService = recordService;
        this.objectMapper = objectMapper;
    }

    /**
     * Redis로부터 읽은 MapRecord를 JSON 문자열로 변환하고, ActivityPayload 객체로 역직렬화한다.
     *
     * @param record Redis Stream에서 읽은 Map 형태의 메시지
     * @return ActivityPayload 역직렬화된 객체
     * @throws Exception 역직렬화 중 오류 발생 시
     */
    @Override
    protected ActivityPayload deserialize(MapRecord<String, Object, Object> record) throws Exception {
        String json = (String) record.getValue().get("payload"); // 메시지 본문
        return objectMapper.readValue(json, ActivityPayload.class);
    }

    /**
     * 역직렬화된 ActivityPayload를 비즈니스 서비스에 전달하여 처리한다.
     *
     * @param payload Redis Stream에서 읽어들인 활동 데이터
     */
    @Override
    public void process(ActivityPayload payload) {
//        throw new RuntimeException("Dead letter processing test");
        recordService.saveActivityFromPayload(payload);
    }
}
