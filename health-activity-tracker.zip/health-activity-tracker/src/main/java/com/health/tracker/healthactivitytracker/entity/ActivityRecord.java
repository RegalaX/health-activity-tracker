package com.health.tracker.healthactivitytracker.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "activity_record")
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ActivityRecord extends AbstractTimeEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // mysql로 위임 (auto_increment)
    private Long id;

    @Column(name = "record_key", nullable = false, unique = true, length = 64)
    private String recordKey;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "source_id", nullable = false)
    private ActivityRecordSource source;

    @Enumerated(EnumType.STRING)
    @Column(name = "activity_type", length = 16)
    private ActivityType activityType; // Enum: STEPS, HEART_RATE 등

    @Column(name = "last_updated_at")
    private LocalDateTime lastUpdatedAt; // 단말 기준 마지막 업데이트 시간

    @Column(name = "memo", length = 32)
    private String memo;

}
