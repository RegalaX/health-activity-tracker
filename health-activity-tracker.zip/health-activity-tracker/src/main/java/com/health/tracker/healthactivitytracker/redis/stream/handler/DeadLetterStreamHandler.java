package com.health.tracker.healthactivitytracker.redis.stream.handler;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.health.tracker.healthactivitytracker.constant.RedisStreamKey;
import com.health.tracker.healthactivitytracker.dto.ActivityPayload;
import com.health.tracker.healthactivitytracker.service.ActivityRecordService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.connection.stream.MapRecord;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

/**
 * 이 클래스는 {@link AbstractStreamHandler}를 확장하여 공통 로직을 재사용한다.
 * Dead Letter Queue (DLQ) 전용 Redis Stream Handler
 *
 * 주요 역할:
 * - 이전에 실패하여 DLQ에 쌓인 메시지를 수신
 * - 역직렬화 후 재처리 시도
 * - 재처리 실패 시, 향후 보존 또는 알림을 위한 확장 지점 제공
 */
@Slf4j
@Component
public class DeadLetterStreamHandler extends AbstractStreamHandler<ActivityPayload> {

    private final ObjectMapper objectMapper;
    private final ActivityRecordService activityRecordService;

    /**
     * DLQ 핸들러 생성자
     *
     * @param redisTemplate Redis 연결 객체
     * @param objectMapper JSON → DTO 역직렬화에 사용
     * @param activityRecordService 재처리 로직을 수행할 서비스
     */
    public DeadLetterStreamHandler(RedisTemplate<String, String> redisTemplate,
                                   ObjectMapper objectMapper,
                                   ActivityRecordService activityRecordService) {
        super(redisTemplate,
                RedisStreamKey.ACTIVITY_STREAM_KEY + RedisStreamKey.ACTIVITY_DEAD_LETTER_SUFFIX, // DLQ 키
                RedisStreamKey.ACTIVITY_DEAD_LETTER_GROUP); // Consumer Group
        this.objectMapper = objectMapper;
        this.activityRecordService = activityRecordService;
    }

    /**
     * Redis 메시지를 ActivityPayload 객체로 변환
     *
     * @param record Redis에서 가져온 스트림 레코드
     * @return 역직렬화된 ActivityPayload 객체
     */
    @Override
    protected ActivityPayload deserialize(MapRecord<String, Object, Object> record) throws Exception {
        String json = (String) record.getValue().get("payload");
        return objectMapper.readValue(json, ActivityPayload.class);
    }

    /**
     * DLQ 메시지를 재처리하는 로직
     *
     * @param payload 역직렬화된 활동 데이터
     */
    @Override
    protected void process(ActivityPayload payload) {
        try {
            log.warn("[DLQ] Retrying processing for payload...");
            activityRecordService.saveActivityFromPayload(payload); // 정상 처리 재시도
        } catch (Exception e) {
            // 재시도 실패 → 로그로 남기고 추후 확장을 고려
            log.error("[DLQ] Final retry failed. payload will be stored. {}", payload, e);

            // TODO:
            // - 실패한 payload를 DB나 파일에 저장
            // - 슬랙/이메일/웹훅 등으로 알림 전송
            // - 최대 재시도 횟수 제한 등 정책 도입 고려
        }
    }
}
