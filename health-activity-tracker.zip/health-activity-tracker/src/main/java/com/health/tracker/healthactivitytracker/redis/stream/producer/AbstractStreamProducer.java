package com.health.tracker.healthactivitytracker.redis.stream.producer;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.health.tracker.healthactivitytracker.constant.RedisStreamKey;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataAccessException;
import org.springframework.data.redis.connection.stream.ObjectRecord;
import org.springframework.data.redis.connection.stream.RecordId;
import org.springframework.data.redis.connection.stream.StreamRecords;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.StreamOperations;

import java.util.Objects;
import java.util.concurrent.*;

/**
 * Redis Stream Producer 추상 클래스.
 * 다양한 Stream에 메시지를 비동기 전송하는 공통 로직을 제공하며,
 * 장애 시 fallback 처리도 지원합니다.
 * 
 * @param <T> 스트림에 전송할 payload 타입
 */
@Slf4j
@RequiredArgsConstructor
public abstract class AbstractStreamProducer<T> implements IStreamProducer {

    /**
     * Redis 연동을 위한 RedisTemplate
     */
    private final RedisTemplate<String, String> redisTemplate;

    /**
     * 메시지 직렬화를 위한 ObjectMapper
     */
    private final ObjectMapper objectMapper;

    private final Integer concurrency;
    /**
     * 메시지 전송을 비동기로 처리하기 위한 ExecutorService
     */
    private ExecutorService executorService;

    /**
     * 구현 클래스가 제공하는 Stream Key
     * @return Redis Stream 키 이름
     */
    protected abstract String streamKey();

    /**
     * Redis 실패 시 DB로 fallback 처리하는 추상 메서드
     * @param payload 전송 실패한 payload
     */
    protected abstract void fallbackToDatabase(T payload);

    /**
     * Executor 초기화
     */
    @Override
    public void start() {
        this.executorService = Executors.newFixedThreadPool(concurrency);
    }

    /**
     * 애플리케이션 종료 시 Executor shutdown
     */
    @Override
    public void shutdown() {
        if (executorService != null) {
            executorService.shutdown();
        }
    }

    /**
     * fallback 처리 수행 후, recordId가 존재하면 Redis에서 해당 메시지를 삭제한다.
     * @param payload 실패한 데이터
     * @param recordId Redis Record ID
     */
    private void fallback(T payload, RecordId recordId) {
        fallbackToDatabase(payload);

        if (recordId != null) {
            redisTemplate.opsForStream().delete(RedisStreamKey.ACTIVITY_STREAM_KEY, recordId);
            log.warn("Deleted failed record from Redis Stream: recordId={}", recordId);
        }
    }

    /**
     * 비동기로 메시지를 Redis Stream에 전송하는 메서드
     * @param payload 스트림에 전송할 payload
     * 한 번의 요청마다 수백~천 건의 운동 기록이 들어옵니다.
     * 이를 동기적으로 저장하면 서블릿 요청 스레드가 DB 작업으로 차단되고,
     * 트래픽이 몰릴 경우 전체 시스템 안정성에 영향을 줄 수 있다고 판단했습니다.
     * 그래서 요청은 Redis Stream에 비동기 전송하고,
     * 실제 DB 저장은 백그라운드 Consumer가 처리하는 구조로 설계했습니다.
     * Redis가 장애날 경우에도 Fallback 처리로 유실없는 저장을 목표로 삼았습니다.
     */
    public void sendAsync(T payload) {
        CompletableFuture.runAsync(() -> send(payload), executorService)
                .orTimeout(3, TimeUnit.SECONDS)
                .exceptionally(e -> {
                    log.error("Async error or timeout during send", e);
                    return null;
                });
    }

    /**
     * 동기적으로 Redis Stream에 메시지를 전송하며, 실패 시 fallback 처리
     * @param payload 전송할 데이터
     */
    private void send(T payload) {
        StreamOperations<String, String, String> streamOps = redisTemplate.opsForStream();
        RecordId recordId = null;

        try {
            // 직렬화
            String json = objectMapper.writeValueAsString(payload);

            // Redis Stream 전송용 레코드 생성
            ObjectRecord<String, String> record = StreamRecords.newRecord()
                    .ofObject(json)
                    .withStreamKey(streamKey());

            // Redis에 전송
            recordId = streamOps.add(record);

            if (Objects.isNull(recordId)) {
                log.warn("Redis Stream returned null RecordId. Falling back to DB.");
                fallback(payload, null);
                return;
            }

            log.debug("Produced to Redis Stream: recordId={}, payload={}", recordId, json);

        } catch (JsonProcessingException e) {
            log.error("Failed to serialize payload", e);
            fallback(payload, recordId);
        } catch (IllegalStateException | DataAccessException e) {
            log.error("Redis access error during Stream production", e);
            fallback(payload, recordId);
        } catch (Exception e) {
            log.error("Unexpected error while sending to Redis", e);
            fallback(payload, recordId);
        }
    }
}