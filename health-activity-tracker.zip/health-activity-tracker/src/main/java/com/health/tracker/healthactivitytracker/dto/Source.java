package com.health.tracker.healthactivitytracker.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class Source {
    @NotEmpty(message = "name은 필수값입니다.")
    private String name;

    @NotNull(message = "mode는 필수값입니다.")
    private Integer mode;

    private String type;

    @Valid
    private Product product;


    @Data
    public static class Product {
        @NotEmpty(message = "name은 필수값입니다.")
        private String name;

        @NotEmpty(message = "vender는 필수값입니다.")
        private String vender;
    }
}

