package com.health.tracker.healthactivitytracker.repository;

import com.health.tracker.healthactivitytracker.entity.ActivityRecord;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface ActivityRecordRepository extends JpaRepository<ActivityRecord, Long> {
    Optional<ActivityRecord> findByRecordKey(String recordKey);
}
