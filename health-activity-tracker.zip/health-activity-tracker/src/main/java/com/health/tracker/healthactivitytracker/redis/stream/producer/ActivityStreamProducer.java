package com.health.tracker.healthactivitytracker.redis.stream.producer;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.health.tracker.healthactivitytracker.constant.RedisStreamKey;
import com.health.tracker.healthactivitytracker.dto.ActivityPayload;
import com.health.tracker.healthactivitytracker.service.ActivityRecordService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

/**
 * 사용자 활동({@link ActivityPayload}) 을 Redis Stream에 전송하는 프로듀서 클래스.
 *
 * - Stream 발행 실패 시 DB에 직접 저장하는 fallback 로직을 통해 데이터 유실을 방지한다.
 * - 내부적으로 {@link AbstractStreamProducer} 를 확장하여 공통 로직을 재사용한다.
 */
@Slf4j
@Component
public class ActivityStreamProducer extends AbstractStreamProducer<ActivityPayload> {

    // Redis Stream으로 전송 실패 시 DB로 직접 저장하기 위한 서비스
    private final ActivityRecordService activityRecordService;

    /**
     * ActivityStreamProducer 생성자.
     *
     * @param redisTemplate RedisTemplate<String, String> – Redis 스트림 전송에 사용
     * @param objectMapper  ObjectMapper – ActivityPayload 객체를 JSON 문자열로 직렬화하는 데 사용
     * @param service       ActivityRecordService – fallback 발생 시 DB 저장 로직을 처리하는 서비스
     */
    public ActivityStreamProducer(RedisTemplate<String, String> redisTemplate,
                                  ObjectMapper objectMapper,
                                  ActivityRecordService service) {
        super(redisTemplate, objectMapper, 5); // 스레드 개수
        this.activityRecordService = service;
    }

    /**
     * 이 프로듀서가 메시지를 발행할 Redis Stream의 key를 정의한다.
     *
     * @return String – Redis Stream Key (예: activity.stream)
     */
    @Override
    protected String streamKey() {
        return RedisStreamKey.ACTIVITY_STREAM_KEY;
    }

    /**
     * Redis Stream 전송 실패 시 수행되는 fallback 로직.
     *
     * - Redis에 메시지 발행이 실패할 경우, 해당 데이터를 DB에 직접 저장하여
     *   데이터 유실 없이 처리할 수 있도록 한다.
     * - 실패 사유는 로그로 남기며, 추후 개선사항으로 실패 데이터 보관(디스크) 또는 알림 연동을 고려할 수 있다.
     *
     * @param payload 전송 대상인 사용자 활동 데이터
     */
    @Override
    protected void fallbackToDatabase(ActivityPayload payload) {
        try {
            activityRecordService.saveActivityFromPayload(payload);
            log.warn("Fallback to DB succeeded for payload");
        } catch (Exception ex) {
            log.error("Fallback to DB failed. Data may be lost. payload={}", payload, ex);
            // TODO: 향후 실패한 데이터를 보존하거나 재처리하기 위한 대체 저장소 또는 로그 적재 고려. 웹훅 발송.
        }
    }
}
