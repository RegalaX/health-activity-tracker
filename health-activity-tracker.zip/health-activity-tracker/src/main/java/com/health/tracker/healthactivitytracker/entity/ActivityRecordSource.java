package com.health.tracker.healthactivitytracker.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "activity_record_source",
        uniqueConstraints = @UniqueConstraint(columnNames = {
                "name", "mode", "type", "productName", "productVendor"
        }))
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ActivityRecordSource extends AbstractTimeEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // mysql로 위임 (auto_increment)
    private Long id;

    @Column(length = 24)
    private String name;

    @Column
    private Integer mode;

    @Column(length = 12)
    private String type;

    @Column(name = "product_name", length = 24)
    private String productName;

    @Column(name = "product_vendor", length = 24)
    private String productVendor;
}
