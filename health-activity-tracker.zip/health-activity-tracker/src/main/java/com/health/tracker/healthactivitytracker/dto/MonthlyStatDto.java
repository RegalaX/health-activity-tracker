package com.health.tracker.healthactivitytracker.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.math.BigDecimal;
import java.time.YearMonth;

@Data
@AllArgsConstructor
public class MonthlyStatDto {
//    private YearMonth month;
    private String month;
    private BigDecimal steps;
    private BigDecimal calories;
    private BigDecimal distance;
}
