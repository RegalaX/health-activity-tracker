package com.health.tracker.healthactivitytracker.redis.stream;

import com.health.tracker.healthactivitytracker.redis.stream.consumer.IStreamConsumer;
import com.health.tracker.healthactivitytracker.redis.stream.producer.IStreamProducer;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Redis Stream Consumer를 애플리케이션 생명주기와 함께 관리하는 Runner 클래스.
 *
 * - Spring Bean으로 등록된 모든 {@link IStreamConsumer} 구현체를 주입받아 일괄 실행/종료 처리한다.
 * - Redis 기반 StreamConsumer들을 애플리케이션 시작 시 자동 실행
 * - {@link AbstractStreamConsumer}를 상속한 모든 Consumer들은 Executor 기반으로 비동기 동작하므로,
 *   Spring 애플리케이션 생명주기 훅에 맞춰 명시적으로 실행(start)과 종료(shutdown)를 관리해야 한다.
 *
 *  사용 목적:
 *  - @PostConstruct를 통해 애플리케이션 시작 시 consumer들을 일괄 실행
 *  - @PreDestroy를 통해 애플리케이션 종료 시 executor 리소스를 안전하게 정리
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class StreamConsumerRunner {

    /**
     * Spring Context 내의 모든 Consumer 구현체 자동 주입.
     * {@link IStreamConsumer} 인터페이스를 구현한 모든 Bean이 대상이 된다.
     */
    private final List<IStreamConsumer> consumers;

    /**
     * 애플리케이션 시작 시 자동 호출됨
     *
     * - 각 Consumer의 start() 메서드를 호출하여 메시지 소비 루프를 시작한다.
     * - Redis Consumer Group 또는 스레드 풀을 초기화하는 작업이 이 시점에 수행된다.
     */
    @PostConstruct
    public void startAll() {
        for (IStreamConsumer consumer : consumers) {
            try {
                consumer.start();
                log.info("Started StreamConsumer: {}", consumer.getClass().getSimpleName());
            } catch (Exception e) {
                log.error("Failed to start consumer: {}", consumer.getClass().getSimpleName(), e);
            }
        }
    }

    /**
     * 애플리케이션 종료 직전에 호출됨.
     * - 각 Producer의 Executor를 안전하게 종료하여 리소스 누수나 쓰레드 유실을 방지
     */
    @PreDestroy
    public void shutdownAll() {
        for (IStreamConsumer consumer : consumers) {
            try {
                consumer.shutdown();
                log.info("Shutdown StreamConsumer: {}", consumer.getClass().getSimpleName());
            } catch (Exception e) {
                log.warn("Failed to shutdown consumer: {}", consumer.getClass().getSimpleName(), e);
            }
        }
    }

    /**
     * 일정 주기로 Redis Stream의 pending 메시지를 조회하고,
     * 일정 시간 이상 idle 된 메시지를 재처리한다.
     */
//    @Scheduled(fixedDelay = 60000) // 1분 주기
//    public void reprocessPendingMessages() {
//        try {
//            PendingMessages pendingMessages = redisTemplate.opsForStream()
//                    .pending(RedisStreamKey.ACTIVITY_STREAM_KEY, Consumer.from(
//                            RedisStreamKey.ACTIVITY_CONSUMER_GROUP, RedisStreamKey.ACTIVITY_RECOVERY_CONSUMER));
//
//            if (pendingMessages == null || pendingMessages.isEmpty()) return;
//
//            List<PendingMessage> expiredMessages = pendingMessages.stream()
//                    .filter(p -> p.getElapsedTimeSinceLastDelivery().toMillis() > 60000)
//                    .limit(10)
//                    .collect(Collectors.toList());
//
//            for (PendingMessage p : expiredMessages) {
//                List<MapRecord<String, Object, Object>> claimed = redisTemplate.opsForStream().claim(
//                        RedisStreamKey.ACTIVITY_STREAM_KEY,
//                        RedisStreamKey.ACTIVITY_CONSUMER_GROUP,
//                        RedisStreamKey.ACTIVITY_RECOVERY_CONSUMER,
//                        Duration.ofMinutes(1),
//                        p.getId()
//                );
//                for (MapRecord<String, Object, Object> record : claimed) {
//                    log.info("Reprocessing idle message from pending: {}", record.getId());
//                    activityStreamHandler.handle(record, RedisStreamKey.ACTIVITY_RECOVERY_CONSUMER);
//                }
//            }
//        } catch (Exception e) {
//            log.error("Failed to reprocess pending messages", e);
//        }
//    }
}
