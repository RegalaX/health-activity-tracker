package com.health.tracker.healthactivitytracker.entity;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "activity_entry")
@IdClass(ActivityEntryId.class)
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ActivityEntry {


    @Id
    @Column(name = "record_id")
    private Long recordId;

    @Id
    @Column(name = "start_time", nullable = false)
    private LocalDateTime startTime; // 복합키로 사용됨.

    @Column(name = "end_time", nullable = false)
    private LocalDateTime endTime;   // period.to

    @Column(name = "steps", precision = 10, scale = 5) // 10 : 전체 자리수, 5 : 소수점 이하 자리수 ex) 12345.12345
    private BigDecimal steps;

    @Column(name = "distance_km", precision = 10, scale = 7)
    private BigDecimal distanceKm;

    @Column(name = "calories_kcal", precision = 10, scale = 4)
    private BigDecimal caloriesKcal;

    @Column(name = "created_at")
    private LocalDateTime createdAt; // ActivityEntry의 경우 saveAllInBatch() 를 사용하여 직접 직접 기입

    // FK는 생략 (파티셔닝 이슈)
    // 관계 접근 필요 시 service layer에서 join 처리
}
