package com.health.tracker.healthactivitytracker.controller;

import com.health.tracker.healthactivitytracker.dto.DailyStatDto;
import com.health.tracker.healthactivitytracker.dto.MonthlyStatDto;
import com.health.tracker.healthactivitytracker.service.ActivityStatisticsService;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;
import java.util.List;


/**
 * 활동 통계 API 컨트롤러
 *
 * 기능 설명:
 * 사용자의 활동 데이터(ActivityEntry)를 기반으로 일별(Daily), 월별(Monthly) 통계 데이터를 조회하는 API를 제공
 *
 * - 대상 데이터는 Redis Stream → DB → 집계 저장소에 저장된 데이터를 기준으로 조회됨
 * - 조회 대상은 recordKey(사용자별 고유 키) 기준으로 제한됨
 *
 * Endpoint
 * - GET /api/statistics/daily
 * - GET /api/statistics/monthly
 */
@RestController
@RequestMapping("/api/statistics")
@RequiredArgsConstructor
public class StatisticsController {

    private final ActivityStatisticsService statisticsService;


    /**
     * 일별 활동 통계 조회 API
     *
     * @param recordKey 활동 기록의 고유 식별자 (activity_record.record_key)
     * @param from 조회 시작일 (yyyy-MM-dd)
     * @param to 조회 종료일 (yyyy-MM-dd)
     * @return {@link DailyStatDto} 리스트 (날짜, 걸음수, 칼로리, 거리)
     *
     * 예시 호출:
     * GET /api/statistics/daily?recordKey=7836887b-b12a-440f-af0f-851546504b13&from=2024-11-15&to=2025-01-31
     */
    @GetMapping("/daily")
    public List<DailyStatDto> getDailyStats(
        @RequestParam String recordKey,
        @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate from,
        @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate to
    ) {
        return statisticsService.getDailyStats(recordKey, from, to);
    }


    /**
     * 월별 활동 통계 조회 API
     *
     * @param recordKey 활동 기록의 고유 식별자 (activity_record.record_key)
     * @param from 조회 시작 월 (yyyy-MM-dd 형식으로 첫날 전달)
     * @param to 조회 종료 월 (yyyy-MM-dd 형식으로 말일 전달 가능)
     * @return {@link MonthlyStatDto} 리스트 (연월, 걸음수, 칼로리, 거리)
     *
     * 🔎 예시 호출:
     * GET /api/statistics/monthly?recordKey=e27ba7ef-8bb2-424c-af1d-877e826b7487&from=2024-11-15&to=2025-01-30
     */
    @GetMapping("/monthly")
    public List<MonthlyStatDto> getMonthlyStats(
        @RequestParam String recordKey,
        @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate from,
        @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate to
    ) {
        return statisticsService.getMonthlyStats(recordKey, from, to);
    }
}
