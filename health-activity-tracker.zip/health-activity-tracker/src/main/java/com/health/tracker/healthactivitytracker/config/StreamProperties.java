package com.health.tracker.healthactivitytracker.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Data
@Configuration
@ConfigurationProperties(prefix = "streams")
public class StreamProperties {
    private List<StreamConfig> configs;

    @Data
    public static class StreamConfig {
        private String name;
        private String key;
        private String group;
        private String handlerBean;
        private int concurrency = 2;
    }
}
