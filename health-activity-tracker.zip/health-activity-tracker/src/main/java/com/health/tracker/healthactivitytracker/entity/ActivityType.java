package com.health.tracker.healthactivitytracker.entity;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public enum ActivityType {
    STEPS("steps");

    private final String strValue;

    public static ActivityType fromString(String activityType) {
        if (activityType == null) {
            throw new IllegalArgumentException("ActivityType string cannot be null");
        }

        for (ActivityType type : ActivityType.values()) {
            if (type.strValue.equalsIgnoreCase(activityType.trim())) {
                return type;
            }
        }

        throw new IllegalArgumentException("Unknown ActivityType: " + activityType);
    }
}
