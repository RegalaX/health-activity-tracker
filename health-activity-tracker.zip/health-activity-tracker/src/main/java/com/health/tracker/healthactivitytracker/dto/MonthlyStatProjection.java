package com.health.tracker.healthactivitytracker.dto;

import java.math.BigDecimal;

public interface MonthlyStatProjection {
    String getMonth();
    BigDecimal getSteps();
    BigDecimal getCalories();
    BigDecimal getDistance();
}