package com.health.tracker.healthactivitytracker.dto;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class UnitValue {
    private String unit;
    private BigDecimal value;
}