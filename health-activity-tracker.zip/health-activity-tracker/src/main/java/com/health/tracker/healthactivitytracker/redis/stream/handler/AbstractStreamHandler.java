package com.health.tracker.healthactivitytracker.redis.stream.handler;

import com.health.tracker.healthactivitytracker.constant.RedisStreamKey;
import com.sun.jdi.request.DuplicateRequestException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.connection.stream.MapRecord;
import org.springframework.data.redis.core.RedisTemplate;

import java.util.Map;

/**
 * Redis Stream 기반 이벤트 처리의 공통 핸들러 추상 클래스.
 * 실제 처리 로직은 {@code deserialize}와 {@code process}를 오버라이드하여 구현.
 *
 * 메시지 수신 → 역직렬화 → 비즈니스 처리 → 성공 시 ACK/삭제 → 실패 시 DLQ 로깅 구조로 처리됨.
 */
@Slf4j
public abstract class AbstractStreamHandler<T> implements IStreamHandler {

    // Redis 연결을 위한 템플릿
    private final RedisTemplate<String, String> redisTemplate;

    // 처리 대상 Redis Stream 키
    private final String streamKey;

    // Redis Consumer Group 이름
    private final String consumerGroup;

    /**
     * 핸들러 초기화: RedisTemplate, Stream Key, Consumer Group 설정
     */
    protected AbstractStreamHandler(RedisTemplate<String, String> redisTemplate, String streamKey, String consumerGroup) {
        this.redisTemplate = redisTemplate;
        this.streamKey = streamKey;
        this.consumerGroup = consumerGroup;
    }

    /**
     * Redis Stream 메시지 처리 진입점.
     * - 역직렬화
     * - 비즈니스 처리
     * - 중복 체크 및 예외 처리
     * - ACK 및 삭제 또는 DLQ로 전달
     *
     * @param record       Redis Stream으로부터 수신한 메시지
     * @param consumerName 처리 중인 Consumer의 이름
     */
    @Override
    public void handle(MapRecord<String, Object, Object> record, String consumerName) {
        boolean success = false;

        try {
            // Step 1: 메시지를 도메인 객체로 역직렬화
            T payload = deserialize(record);

            // Step 2: 실제 처리 로직 실행
            process(payload);

            success = true;
        } catch (Exception e) {
            // 중복 데이터인 경우는 무시하고 통과
            if (isDuplicateException(e)) {
                log.warn("[{}] Duplicate record {}, skipping", consumerName, record.getId());
                success = true;
            } else {
                // Step 3: 비정상 실패 → Dead Letter Queue로 이관
                log.error("[{}] Failed to process record {}, sending to DLQ: {}", consumerName, record.getId(), e.getMessage());
                sendToDeadLetter(record, e.getMessage());
            }
        }

        if (success) {
            try {
                // Step 4: 정상 처리된 메시지를 ack 및 삭제
                redisTemplate.opsForStream().acknowledge(consumerGroup, record);
                redisTemplate.opsForStream().delete(streamKey, record.getId());
            } catch (Exception e) {
                log.warn("Failed to ack/delete record {}", record.getId(), e);
            }
        }
    }

    /**
     * DLQ(Dead Letter Queue)로 실패한 메시지를 전송.
     * - 원본 payload와 에러 메시지를 함께 전송
     * - DLQ Key는 streamKey + .dead.letter 접미어
     *
     * @param record 실패한 레코드
     * @param reason 예외 메시지
     */
    protected void sendToDeadLetter(MapRecord<String, Object, Object> record, String reason) {
        try {
            redisTemplate.opsForStream().add(streamKey + RedisStreamKey.ACTIVITY_DEAD_LETTER_SUFFIX, Map.of(
                    "payload", record.getValue().get("payload"),
                    "error", reason
            ));
        } catch (Exception e) {
            log.error("Failed to write to DLQ: {}", e.getMessage());
        }
    }

    /**
     * 예외가 중복 키 관련 여부인지 확인한다.
     * - DB 제약 조건 또는 요청 중복에 의한 오류를 식별하기 위한 로직
     *
     * @param e 예외 객체
     * @return 중복 예외 여부
     */
    protected boolean isDuplicateException(Exception e) {
        return (e instanceof DuplicateRequestException) ||
                (e.getMessage() != null && e.getMessage().contains("Duplicate entry"));
    }

    /**
     * 메시지를 T 타입으로 역직렬화하는 메서드 (서브 클래스에서 구현)
     *
     * @param record 수신된 레코드
     * @return 역직렬화된 payload 객체
     */
    protected abstract T deserialize(MapRecord<String, Object, Object> record) throws Exception;

    /**
     * 실제 비즈니스 로직 처리 메서드 (서브 클래스에서 구현)
     *
     * @param payload 역직렬화된 메시지 객체
     */
    protected abstract void process(T payload) throws Exception;
}
