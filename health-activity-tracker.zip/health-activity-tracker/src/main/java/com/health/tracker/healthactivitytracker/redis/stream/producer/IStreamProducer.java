package com.health.tracker.healthactivitytracker.redis.stream.producer;

public interface IStreamProducer {
    void start();
    void shutdown();
}
