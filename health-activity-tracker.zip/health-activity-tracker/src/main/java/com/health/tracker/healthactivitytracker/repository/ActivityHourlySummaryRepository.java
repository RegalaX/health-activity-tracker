package com.health.tracker.healthactivitytracker.repository;

import com.health.tracker.healthactivitytracker.entity.ActivityHourlySummary;
import com.health.tracker.healthactivitytracker.entity.ActivityHourlySummaryId;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ActivityHourlySummaryRepository extends JpaRepository<ActivityHourlySummary, ActivityHourlySummaryId> {
}
