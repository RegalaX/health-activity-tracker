package com.health.tracker.healthactivitytracker.controller;


import com.health.tracker.healthactivitytracker.dto.ActivityPayload;
import com.health.tracker.healthactivitytracker.redis.stream.producer.ActivityStreamProducer;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;




/**
 * 사용자 활동(Activity) 데이터를 수신하는 API 컨트롤러
 *
 * 주요 역할
 * - 클라이언트 단말 (예: 모바일 앱)에서 전달한 활동 데이터를 수신
 * - 수신된 데이터를 Redis Stream에 비동기로 발행
 * - 발행 실패 시 Fallback 로직을 통해 DB에 직접 저장
 */
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/activity")
@Slf4j
public class ActivityController {

    private final ActivityStreamProducer producer;

    /**
     * 활동 데이터 수신 API
     *
     * @param payload {@link ActivityPayload}: 사용자의 건강활동 정보(JSON 구조로 전달됨)
     * @return HTTP 200 OK (요청 수락 완료)
     *
     * 처리 흐름:
     * 1. 단말에서 전송된 JSON 데이터를 @Valid로 검증 후 @RequestBody로 수신
     * 2. Redis Stream Producer를 통해 Stream에 메시지 발행 (비동기 처리)
     * 3. 발행 중 오류 발생 시 내부적으로 Fallback 로직이 실행됨
     *
     * 예시 호출:
     * POST /api/activity
     * Content-Type: application/json
     * {
     *   "recordKey": "e27ba7ef-8bb2-424c-af1d-877e826b7487",
     *   "type": "steps",
     *   "lastUpdate": "2024-11-01T08:00:00Z",
     *   "data": {
     *     "entries": [...],
     *     "source": {...}
     *   }
     * }
     */
    @PostMapping
    public ResponseEntity<Void> postActivity(@Valid @RequestBody ActivityPayload payload) {
        producer.sendAsync(payload);
        return ResponseEntity.ok().build();
    }
}
