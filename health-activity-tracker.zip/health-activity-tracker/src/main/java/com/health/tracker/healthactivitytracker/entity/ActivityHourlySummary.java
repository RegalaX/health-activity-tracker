package com.health.tracker.healthactivitytracker.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "activity_hourly_summary")
@IdClass(ActivityHourlySummaryId.class)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ActivityHourlySummary {

    @Id
    @Column(name = "record_key", length = 64, nullable = false)
    private String recordKey;

    @Id
    @Column(name = "hourly", nullable = false)
    private LocalDateTime hourly;

    @Column(name = "steps", nullable = true)
    private Double steps;

    @Column(name = "calories", nullable = true)
    private Double calories;

    @Column(name = "distance", nullable = true)
    private Double distance;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
}
