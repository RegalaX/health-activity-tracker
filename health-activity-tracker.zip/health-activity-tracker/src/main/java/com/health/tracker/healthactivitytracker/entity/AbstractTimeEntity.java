package com.health.tracker.healthactivitytracker.entity;


import jakarta.persistence.EntityListeners;
import jakarta.persistence.MappedSuperclass;
import lombok.Getter;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.LocalDateTime;

@Getter
@MappedSuperclass // 해당 추상 클래스를 상속하는 엔티티들이 아래 필드들을 컬럼으로 인식하기 위함.
@EntityListeners(AuditingEntityListener.class) // 해당 추상 클래스에 Auditing 기능을 포함시키기 위함.
public abstract class AbstractTimeEntity {

    @CreatedDate
    private LocalDateTime createdAt; //Entity가 생성되어 저장될 때 시간이 자동 저장
}
