package com.health.tracker.healthactivitytracker.service;

import com.health.tracker.healthactivitytracker.dto.DailyStatDto;
import com.health.tracker.healthactivitytracker.dto.MonthlyStatDto;
import com.health.tracker.healthactivitytracker.entity.ActivityRecord;
import com.health.tracker.healthactivitytracker.repository.ActivityEntryRepository;
import com.health.tracker.healthactivitytracker.repository.ActivityRecordRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ActivityStatisticsService {

    private final ActivityRecordRepository recordRepository;
    private final ActivityEntryRepository entryRepository;

    public List<DailyStatDto> getDailyStats(String recordKey, LocalDate from, LocalDate to) {
        ActivityRecord record = recordRepository.findByRecordKey(recordKey)
                .orElseThrow(() -> new IllegalArgumentException("Record not found: " + recordKey));

        LocalDateTime fromDateTime = from.atStartOfDay();
        LocalDateTime toDateTime = to.atStartOfDay();

        return entryRepository.findDailyStat(
                        record.getId(),
                        fromDateTime,
                        toDateTime
                ).stream()
                .map(p -> new DailyStatDto(
                        p.getDate(),
                        p.getSteps(),
                        p.getCalories(),
                        p.getDistance()
                ))
                .collect(Collectors.toList());
    }

    public List<MonthlyStatDto> getMonthlyStats(String recordKey, LocalDate from, LocalDate to) {
        ActivityRecord record = recordRepository.findByRecordKey(recordKey)
                .orElseThrow(() -> new IllegalArgumentException("Record not found: " + recordKey));

        LocalDateTime fromDateTime = from.withDayOfMonth(1).atStartOfDay();
        LocalDateTime toDateTime = to.withDayOfMonth(1).plusMonths(1).atStartOfDay();

        return entryRepository.findMonthlyStat(
                        record.getId(),
                        fromDateTime,
                        toDateTime
                ).stream()
                .map(p -> new MonthlyStatDto(
                        p.getMonth(),
                        p.getSteps(),
                        p.getCalories(),
                        p.getDistance()
                ))
                .collect(Collectors.toList());
    }
}
