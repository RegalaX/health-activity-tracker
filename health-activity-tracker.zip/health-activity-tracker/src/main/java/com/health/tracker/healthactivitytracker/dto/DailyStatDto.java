package com.health.tracker.healthactivitytracker.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
@AllArgsConstructor
public class DailyStatDto {
    private LocalDate date;
    private BigDecimal steps;
    private BigDecimal calories;
    private BigDecimal distance;
}
