package com.health.tracker.healthactivitytracker.service;

import com.health.tracker.healthactivitytracker.entity.ActivityRecordSource;
import com.health.tracker.healthactivitytracker.repository.ActivitySourceRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Slf4j
@Service
@RequiredArgsConstructor
public class ActivitySourceCacheManager {

    private final ActivitySourceRepository repo;

    private final Map<String, ActivityRecordSource> localCache = new ConcurrentHashMap<>();

    public ActivityRecordSource getOrSaveSource(String name, Integer mode, String type, String productName, String productVendor) {
        String key = name + "-" + mode + "-" + type + "-" + productName + "-" + productVendor;

        return localCache.computeIfAbsent(key, k -> repo.findByNameAndModeAndTypeAndProductNameAndProductVendor(
                        name, mode, type, productName, productVendor)
                .orElseGet(() -> repo.save(ActivityRecordSource.builder()
                        .name(name)
                        .mode(mode)
                        .type(type)
                        .productName(productName)
                        .productVendor(productVendor)
                        .build())));

    }
}
