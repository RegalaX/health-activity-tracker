package com.health.tracker.healthactivitytracker.redis.stream.consumer;

public interface IStreamConsumer {
    void start();
    void shutdown();
}