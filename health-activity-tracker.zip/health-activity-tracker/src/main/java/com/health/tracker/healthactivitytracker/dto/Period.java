package com.health.tracker.healthactivitytracker.dto;

import lombok.Data;

@Data
public class Period {
    private String from;
    private String to;
}