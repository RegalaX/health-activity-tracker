package com.health.tracker.healthactivitytracker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;


@EnableJpaAuditing // audit 기능을 사용하여 createdAt 자동 설정을 위함
@SpringBootApplication
public class HealthActivityTrackerApplication {

    public static void main(String[] args) {
        SpringApplication.run(HealthActivityTrackerApplication.class, args);
    }

}
