package com.health.tracker.healthactivitytracker.redis.stream.consumer;

import com.health.tracker.healthactivitytracker.constant.RedisStreamKey;
import com.health.tracker.healthactivitytracker.redis.stream.handler.DeadLetterStreamHandler;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;


/**
 * Dead Letter Queue (DLQ) 전용 Redis Stream Consumer
 *
 * 역할
 * - Redis Dead Letter Stream (예: activity.stream.dead.letter)로부터 메시지를 소비
 * - 실패한 메시지를 재처리하는 핸들러({@link DeadLetterStreamHandler})와 연결됨
 * - 병렬 처리는 1개 스레드로 설정 (최소한의 처리량 보장)
 */
@Component
public class DeadLetterStreamConsumer extends AbstractStreamConsumer<DeadLetterStreamHandler> {

    public DeadLetterStreamConsumer(RedisTemplate<String, String> redisTemplate, DeadLetterStreamHandler handler) {
        super(redisTemplate, handler, RedisStreamKey.ACTIVITY_STREAM_KEY + RedisStreamKey.ACTIVITY_DEAD_LETTER_SUFFIX,
              RedisStreamKey.ACTIVITY_DEAD_LETTER_GROUP, 2);
    }
}
