package com.health.tracker.healthactivitytracker.redis.stream.consumer;

import com.health.tracker.healthactivitytracker.redis.stream.handler.IStreamHandler;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.connection.stream.*;
import org.springframework.data.redis.core.RedisTemplate;

import java.time.Duration;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;


/**
 * Redis Stream Consumer 추상 클래스.
 * 각 Stream마다 공통적으로 필요한 처리 흐름을 제공하며
 * 실제 처리 로직은 StreamMessageHandler 구현체를 통해 위임받습니다.
 * <p>
 * 주요 기능:
 * - Redis Stream Consumer Group 자동 생성
 * - 멀티 쓰레드로 Redis Stream 메시지 처리
 * - 메시지 소비 시 지정된 handler로 위임
 * - graceful shutdown 처리
 *
 * @param <T> StreamMessageHandler 구현체 타입
 */
@Slf4j
public abstract class AbstractStreamConsumer<T extends IStreamHandler> implements IStreamConsumer {

    // Redis 연결을 위한 RedisTemplate
    private final RedisTemplate<String, String> redisTemplate;

    // 실제 메시지 처리를 담당할 핸들러 (예: ActivityStreamHandler)
    private final T handler;

    // Redis Stream key (예: activity.stream)
    private final String streamKey;

    // Redis Consumer Group 이름
    private final String group;

    // Consumer 식별을 위한 고유 ID
    private final String consumerId;

    // 병렬 처리할 쓰레드 수
    private final int concurrency;

    // 메시지 소비를 위한 스레드 풀
    private ExecutorService executor;

    /**
     * 생성자: 필수 파라미터를 전달받아 초기화
     *
     * @param redisTemplate RedisTemplate 인스턴스
     * @param handler       메시지 처리 핸들러
     * @param streamKey     Redis Stream 키
     * @param group         Consumer Group 이름
     * @param concurrency   동시에 실행할 스레드 수
     */
    protected AbstractStreamConsumer(RedisTemplate<String, String> redisTemplate, T handler, String streamKey, String group, int concurrency) {
        this.redisTemplate = redisTemplate;
        this.handler = handler;
        this.streamKey = streamKey;
        this.group = group;
        this.consumerId = group.toLowerCase() + "-" + UUID.randomUUID();
        this.concurrency = concurrency;
    }


    /**
     * Consumer 시작 시 호출됨.
     * - Consumer Group을 생성 (이미 존재하면 무시)
     * - 지정된 개수만큼 쓰레드를 시작하여 메시지를 비동기적으로 소비
     */
    @Override
    public void start() {
        try {
            // 최초 실행 시 Stream과 Group이 모두 존재해야 Group 생성 가능
            redisTemplate.opsForStream().createGroup(streamKey, group);
        } catch (Exception e) {
            log.info("Group {} already exists or stream {} not initialized", group, streamKey);
        }

        executor = Executors.newFixedThreadPool(concurrency);

        // 쓰레드 수만큼 리스너 실행
        for (int i = 0; i < concurrency; i++) {
            String consumerName = group + ":" + consumerId + ":" + i;
            executor.submit(() -> listen(consumerName));
        }
    }

    /**
     * Redis Stream 메시지를 지속적으로 소비하는 루프.
     * - 메시지를 읽고 handler에게 위임하여 처리
     * - 예외 발생 시 재시도 (짧은 딜레이 포함)
     *
     * @param consumerName 각 스레드별 고유 Consumer 이름
     */
    private void listen(String consumerName) {
        while (!Thread.currentThread().isInterrupted()) {
            try {
                // 최대 10건까지, 500ms 대기 후 읽기
                List<MapRecord<String, Object, Object>> records = redisTemplate.opsForStream().read(
                        Consumer.from(group, consumerName),
                        StreamReadOptions.empty().block(Duration.ofMillis(500)).count(10),
                        StreamOffset.create(streamKey, ReadOffset.lastConsumed())
                );

                if (records == null || records.isEmpty()) {
                    Thread.sleep(200); // idle 상태 시 일시 대기
                    continue;
                }

                // 개별 메시지 처리
                for (MapRecord<String, Object, Object> record : records) {
                    handler.handle(record, consumerName);
                }

            } catch (Exception e) {
                log.warn("[{}] Error consuming from stream {}", consumerName, streamKey, e);
                try {
                    Thread.sleep(1000); // 에러 발생 시 백오프
                } catch (InterruptedException ex) {
                    Thread.currentThread().interrupt();
                }
            }
        }
    }


    /**
     * 애플리케이션 종료 시 호출.
     * - ExecutorService를 종료하여 모든 메시지 소비 스레드를 안전하게 정지시킴
     */
    @Override
    public void shutdown() {
        log.info("Shutting down stream consumer for {}", streamKey);
        executor.shutdown(); // 스레드 풀 종료 요청
        try {
            if (!executor.awaitTermination(10, TimeUnit.SECONDS)) {
                executor.shutdownNow(); // 정상 종료되지 않으면 강제 종료
            }
        } catch (InterruptedException e) {
            executor.shutdownNow();
        }
    }
}
