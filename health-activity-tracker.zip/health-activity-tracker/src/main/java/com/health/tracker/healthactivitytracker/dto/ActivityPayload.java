package com.health.tracker.healthactivitytracker.dto;


import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import lombok.Data;


@Data
public class ActivityPayload {
    @NotEmpty(message = "recordkey는 필수값입니다.")
    private String recordkey;
    @NotEmpty(message = "type은 필수값입니다.")
    private String type;
    @NotEmpty(message = "lastUpdate는 필수값입니다.")
    private String lastUpdate;
    @Valid
    private ActivityData data;
}
