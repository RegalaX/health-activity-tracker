package com.health.tracker.healthactivitytracker.redis.stream;

import com.health.tracker.healthactivitytracker.redis.stream.producer.IStreamProducer;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Redis Stream Producer들을 자동으로 관리하는 런너 클래스.
 *
 * - Spring Bean으로 등록된 모든 {@link IStreamProducer} 구현체를 주입받아 일괄 실행/종료 처리한다.
 * - {@link AbstractStreamProducer}를 상속한 모든 Producer들은 Executor 기반으로 비동기 동작하므로,
 *   Spring 애플리케이션 생명주기 훅에 맞춰 명시적으로 실행(start)과 종료(shutdown)를 관리해야 한다.
 *
 * 사용 목적:
 * - @PostConstruct를 통해 애플리케이션 시작 시 producer들을 일괄 실행
 * - @PreDestroy를 통해 애플리케이션 종료 시 executor 리소스를 안전하게 정리
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class StreamProducerRunner {

    /**
     * Spring Context 내의 모든 Producer 구현체 자동 주입.
     * {@link IStreamProducer} 인터페이스를 구현한 모든 Bean이 대상이 된다.
     */
    private final List<IStreamProducer> producers;

    /**
     * 애플리케이션 시작 시 호출됨.
     * - 모든 Producer의 Executor 또는 쓰레드 풀을 시작시켜 비동기 메시지 전송 준비를 완료한다.
     */
    @PostConstruct
    public void startAll() {
        for (IStreamProducer producer : producers) {
            try {
                producer.start();
                log.info("Started StreamProducer: {}", producer.getClass().getSimpleName());
            } catch (Exception e) {
                log.error("Failed to initialize producer: {}", producer.getClass().getSimpleName(), e);
            }
        }
    }

    /**
     * 애플리케이션 종료 직전에 호출됨.
     * - 각 Producer의 Executor를 안전하게 종료하여 리소스 누수나 쓰레드 유실을 방지
     */
    @PreDestroy
    public void shutdownAll() {
        for (IStreamProducer producer : producers) {
            try {
                producer.shutdown();
                log.info("Shutdown StreamProducer: {}", producer.getClass().getSimpleName());
            } catch (Exception e) {
                log.warn("Failed to shutdown producer: {}", producer.getClass().getSimpleName(), e);
            }
        }
    }
}