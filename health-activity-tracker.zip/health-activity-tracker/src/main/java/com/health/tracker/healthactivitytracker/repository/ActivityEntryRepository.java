package com.health.tracker.healthactivitytracker.repository;

import com.health.tracker.healthactivitytracker.dto.DailyStatProjection;
import com.health.tracker.healthactivitytracker.dto.MonthlyStatProjection;
import com.health.tracker.healthactivitytracker.entity.ActivityEntry;
import com.health.tracker.healthactivitytracker.entity.ActivityEntryId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDateTime;
import java.util.List;

public interface ActivityEntryRepository extends JpaRepository<ActivityEntry, ActivityEntryId> {

    List<ActivityEntry> findByStartTimeBetween(LocalDateTime oneHourAgo, LocalDateTime thisHour);
    List<ActivityEntry> findByRecordIdAndStartTimeBetween(Long recordId, LocalDateTime start, LocalDateTime end);

    @Query(value = """
    SELECT 
        DATE(e.start_time) AS date,
        SUM(e.steps) AS steps,
        SUM(e.calories_kcal) AS calories,
        SUM(e.distance_km) AS distance
    FROM activity_entry e
    JOIN activity_record r ON e.record_id = r.id
    WHERE r.record_key = (SELECT record_key FROM activity_record WHERE id = :recordId)
      AND e.start_time >= :from
      AND e.start_time < :to
    GROUP BY DATE(e.start_time), r.record_key
    ORDER BY r.record_key, DATE(e.start_time)
    """, nativeQuery = true)
    List<DailyStatProjection> findDailyStat(
            @Param("recordId") Long recordId,
            @Param("from") LocalDateTime from,
            @Param("to") LocalDateTime to
    );

    @Query(value = """
        SELECT 
            DATE_FORMAT(e.start_time, '%Y-%m') AS month,
            SUM(e.steps) AS steps,
            SUM(e.calories_kcal) AS calories,
            SUM(e.distance_km) AS distance
        FROM activity_entry e
        JOIN activity_record r ON e.record_id = r.id
        WHERE r.record_key = (SELECT record_key FROM activity_record WHERE id = :recordId)
          AND e.start_time >= :from
          AND e.start_time < :to
        GROUP BY DATE_FORMAT(e.start_time, '%Y-%m'), r.record_key
        ORDER BY r.record_key, DATE_FORMAT(e.start_time, '%Y-%m')
        """, nativeQuery = true)
    List<MonthlyStatProjection> findMonthlyStat(
            @Param("recordId") Long recordId,
            @Param("from") LocalDateTime from,
            @Param("to") LocalDateTime to
    );
}
