package com.health.tracker.healthactivitytracker.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import lombok.Data;

import java.util.List;

@Data
public class ActivityData {
    private String memo; // 선택적 필드

    @NotEmpty(message = "entries는 비어 있을 수 없습니다.")
    private List<ActivityEntryDto> entries;
    @Valid
    private Source source;
}