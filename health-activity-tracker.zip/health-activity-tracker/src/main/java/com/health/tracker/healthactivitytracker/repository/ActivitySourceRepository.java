package com.health.tracker.healthactivitytracker.repository;

import com.health.tracker.healthactivitytracker.entity.ActivityRecordSource;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface ActivitySourceRepository extends JpaRepository<ActivityRecordSource, Long> {

    Optional<ActivityRecordSource> findByNameAndModeAndTypeAndProductNameAndProductVendor(
            String sourceName,
            Integer sourceMode,
            String sourceType,
            String productName,
            String vendor
    );
}
