package com.health.tracker.healthactivitytracker.repository;

import com.health.tracker.healthactivitytracker.entity.ActivityEntry;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

@Repository
@RequiredArgsConstructor
public class ActivityEntryJdbcRepository {

    private final JdbcTemplate jdbcTemplate;

    public void batchInsert(List<ActivityEntry> entries) {
        String sql = """
            INSERT INTO activity_entry (
                record_id,
                start_time,
                end_time,
                steps,
                distance_km,
                calories_kcal,
                created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
            """;

        jdbcTemplate.batchUpdate(sql, new BatchPreparedStatementSetter() {

            @Override
            public void setValues(PreparedStatement ps, int i) throws SQLException {
                ActivityEntry entry = entries.get(i);
                ps.setLong(1, entry.getRecordId());
                ps.setObject(2, entry.getStartTime());
                ps.setObject(3, entry.getEndTime());
                ps.setBigDecimal(4, entry.getSteps());
                ps.setBigDecimal(5, entry.getDistanceKm());
                ps.setBigDecimal(6, entry.getCaloriesKcal());
                ps.setObject(7, entry.getCreatedAt());
            }

            @Override
            public int getBatchSize() {
                return entries.size();
            }
        });
    }
}
