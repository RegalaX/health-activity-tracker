package com.health.tracker.healthactivitytracker.dto;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class ActivityEntryDto {
    private Period period;
    private UnitValue distance;
    private UnitValue calories;
    private BigDecimal steps; // 문자형일 수도 있으므로 파싱 유의

}