package com.health.tracker.healthactivitytracker.constant;

public class RedisStreamKey {
    public static final String ACTIVITY_STREAM_KEY = "activity.stream";
    public static final String ACTIVITY_CONSUMER_GROUP = "activity.consumer.group";
    public static final String ACTIVITY_DEAD_LETTER_SUFFIX = ".dead.letter";
    public static final String ACTIVITY_DEAD_LETTER_GROUP = "activity.dead.letter.group";
}
