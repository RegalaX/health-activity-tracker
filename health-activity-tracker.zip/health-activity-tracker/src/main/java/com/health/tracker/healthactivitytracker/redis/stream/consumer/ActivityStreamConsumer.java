package com.health.tracker.healthactivitytracker.redis.stream.consumer;

import com.health.tracker.healthactivitytracker.constant.RedisStreamKey;
import com.health.tracker.healthactivitytracker.redis.stream.handler.ActivityStreamHandler;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;


/**
 * 사용자 활동 데이터를 수신하는 Redis Stream Consumer.
 *
 * - Redis Stream Key: activity.stream
 * - Consumer Group: activity.consumer.group
 * - 처리 핸들러: {@link ActivityStreamHandler}
 *
 * 이 클래스는 {@link AbstractStreamConsumer}를 확장하여 공통 로직을 재사용한다.
 * Redis Stream에서 수신된 활동 데이터를 병렬로 소비하고 처리한다.
 */
@Component
public class ActivityStreamConsumer extends AbstractStreamConsumer<ActivityStreamHandler> {

    private static final Integer CONCURRENCY = 4;

    public ActivityStreamConsumer(RedisTemplate<String, String> redisTemplate, ActivityStreamHandler handler) {
        super(redisTemplate, handler, RedisStreamKey.ACTIVITY_STREAM_KEY, RedisStreamKey.ACTIVITY_CONSUMER_GROUP, CONCURRENCY);
    }
}